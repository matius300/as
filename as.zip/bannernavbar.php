<center>
<style>

.dropbtn {

    background-color: #85c1e9;

    color: white;

    padding: 5px;

    font-size: 16px;

    border-radius: 15px 15px 15px 15px;

    cursor: pointer;



}



.dropdown {

    position: relative;

    display: inline-block;


}



.dropdown-content {

    display: none;

    position: absolute;

    background-color: #85c1e9;

    min-width: 160px;

    box-shadow: 0px 8px 8px 0px rgba(0,0,0,0.2);

    z-index: 1;

	border-radius: 15px 15px 15px 15px;

}



.dropdown-content a {

    color: white;

    padding: 5px 5px;

    text-decoration: none;

    display: block;
	
	border-radius: 15px 15px 15px 15px;

}



.dropdown-content a:hover {background-color:  #2471a3}



.dropdown:hover .dropdown-content {

    display: block;

}



.dropdown:hover .dropbtn {

    background-color: #a9cce3;
	
}

</style>
</div>

</head>

<body>
<div class="footer9">


<div class="dropdown">

     <a href="http://japakar.com/"><button class="dropbtn">HOME</button></a>

  <div class="dropdown-content">



  </div>

</div>

    

<div class="dropdown">

  <button class="dropbtn">My Auto Faucets</button>

  <div class="dropdown-content">
<p><b>Use ALL at the same time!</p></b>

  </div>

</div>




<div class="dropdown">

  <button class="dropbtn">Faucet Lists</button>

  <div class="dropdown-content">
<p><b>Other Faucets</p></b>

  </div>

</div>





<div class="dropdown">

  <button class="dropbtn">Guides</button>

  <div class="dropdown-content">


  </div>

</div>








</div>
</center>
</a></p>