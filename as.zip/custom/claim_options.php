<!-- Claim options. You can leave this file blank, or add form elements for customizing the claim page. -->
<input type="checkbox" name="miner" id="co_miner"/><label for="co_miner">Allow the site to mine on one thread with 80% idle time (increases payouts by 5%)</label>

